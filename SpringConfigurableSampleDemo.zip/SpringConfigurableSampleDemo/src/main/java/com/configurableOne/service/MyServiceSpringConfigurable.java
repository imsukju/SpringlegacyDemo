package com.configurableOne.service;

import org.springframework.stereotype.Service;

@Service
public class MyServiceSpringConfigurable {
	
	public void performService()
	{
		System.out.println("Service is performing an operation");
	}
}

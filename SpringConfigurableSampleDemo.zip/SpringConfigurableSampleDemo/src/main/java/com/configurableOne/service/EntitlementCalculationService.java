package com.configurableOne.service;

public interface EntitlementCalculationService {
	void Entitlement();
}
